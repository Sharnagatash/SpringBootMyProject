/*Task5-166 -Design API to download all the matured policies details into Excel file*/
package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDownloadMpd166Task5Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDownloadMpd166Task5Application.class, args);
	}

}
