package com.project.service;

import com.project.model.PoliciesD;

public interface PDService {
	public PoliciesD getPoliciesDById(PoliciesD policiesD);

}
