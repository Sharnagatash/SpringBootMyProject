package com.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootDownloadMpd166Task5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
